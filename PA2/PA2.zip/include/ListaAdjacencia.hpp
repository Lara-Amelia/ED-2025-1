#ifndef LISTAADJACENCIA_HPP
#define LISTAADJACENCIA_HPP

#include "ListaEncadeada.hpp"

class NodeAdj
{
    private:
    int vertice;
    ListaEncadeada listaArestas;
    NodeAdj* prox;

    public:
    NodeAdj();
    NodeAdj(int nroVer);
    void setVer(int nroVer);
    int getVer(int pos);

    friend class Grafo;
    friend class ListaAdjacencia;
};

class ListaAdjacencia
{
    private:
    int tamanho;
    NodeAdj *head;
    NodeAdj *tail;
    NodeAdj *PosicionaAntesAdj(int pos);
    NodeAdj *PosicionaEmAdj(int pos);

    public:
    ListaAdjacencia();
    ~ListaAdjacencia();
    void InsereVert(int nroVert, int pos);
    void InsereAresta(int v, int e);
    int pesquisaVert(int pesquisado);
    //int pesquisaAresta(int pesquisado); veremos se é útil
    void ImprimeAdj();
    void LimpaAdj();
    int* geraVetorTam();

    friend class Grafo;
};

#endif